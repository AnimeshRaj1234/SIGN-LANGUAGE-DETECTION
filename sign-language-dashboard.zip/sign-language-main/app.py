"""SignBridge - ASL & ISL Recognition Studio (Flask). Run:  python app.py
Trained models are only *loaded* here; training happens separately in the Kaggle/Colab notebooks.
"""
import logging
import os

from flask import Flask, jsonify, render_template, request

from services.models import LANGS, MODES, ModelStore, read_results
from services.vision import Vision, VisionError

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024 + 1024      # reject oversized frames before reading them

store = ModelStore()          # models load ONCE at startup, never per request
vision = Vision(store)


def err(code, message, status):
    return jsonify({"error": {"code": code, "message": message}}), status


def lang_arg(value):
    if value not in LANGS:
        raise VisionError("invalid_request", "lang must be 'asl' or 'isl'.", 400)
    return value


@app.errorhandler(VisionError)
def _vision_error(e):
    return err(e.code, e.message, e.status)


@app.errorhandler(404)
def _404(_):
    return err("not_found", "Not found.", 404) if request.path.startswith("/api/") else ("Not found", 404)


@app.errorhandler(413)
def _413(_):
    return err("frame_too_large", "Request is larger than 2 MB.", 413)


@app.errorhandler(Exception)
def _500(e):
    app.logger.exception("unhandled error")            # details stay in the server log, never in the response
    return err("server_error", "Unexpected server error. Check the server console.", 500)


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/status")
def status():
    modes = {m: {k: v for k, v in store.describe(m).items() if k in ("available", "reason", "n_labels")} for m in MODES}
    return jsonify({"server": "ok", "modes": modes, "torch": store.torch_ok, "mediapipe_assets": store.assets(),
                    "notes": store.notes})


@app.get("/api/models")
def models():
    return jsonify({"models": [store.describe(m) for m in MODES]})


@app.get("/api/metrics")
def metrics():
    out = []
    for m in MODES:
        d = store.describe(m)
        out.append({"id": m, "lang": d["lang"], "kind": d["kind"], "n_labels": d["n_labels"], "saved": d["metrics"],
                    "note": d.get("metrics_note"), "eval_results": d["eval_results"]})
    return jsonify({"metrics": out})


@app.post("/api/predict/letter")
def predict_letter():
    return jsonify(vision.letter(lang_arg(request.args.get("lang")), request.get_data()))


@app.post("/api/predict/word/start")
def word_start():
    body = request.get_json(silent=True) or {}
    return jsonify(vision.word_start(lang_arg(body.get("lang"))))


@app.post("/api/predict/word/frame")
def word_frame():
    return jsonify(vision.word_frame(request.args.get("session", ""), request.get_data()))


@app.post("/api/predict/word/finish")
def word_finish():
    return jsonify(vision.word_finish((request.get_json(silent=True) or {}).get("session", "")))


@app.post("/api/predict/word/cancel")
def word_cancel():
    vision.word_cancel((request.get_json(silent=True) or {}).get("session", ""))
    return jsonify({"ok": True})


if __name__ == "__main__":
    # 127.0.0.1 keeps the camera page on a "secure context" (localhost), which browsers require for getUserMedia.
    app.run(host=os.environ.get("HOST", "127.0.0.1"), port=int(os.environ.get("PORT", 5000)), threaded=True)
