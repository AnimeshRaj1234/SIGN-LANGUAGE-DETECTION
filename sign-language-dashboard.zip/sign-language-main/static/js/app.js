/* SignBridge front end: camera, throttled inference requests, transcript, charts (plain CSS bars). */
const $ = (s) => document.querySelector(s), $$ = (s) => [...document.querySelectorAll(s)];
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const pct = (v, d = 1) => (v * 100).toFixed(d) + "%";
// Model labels are lower-case with spaces removed (e.g. goodmorning). Display-only prettifying; the raw label is never altered.
const PRETTY = { thankyou: "thank you", goodmorning: "good morning", biglarge: "big / large", smalllittle: "small / little",
  storeorshop: "store / shop", trainticket: "train ticket", tshirt: "t-shirt", youplural: "you (plural)", i: "I" };
const pretty = (l) => PRETTY[l] ?? l;

const S = { lang: "asl", kind: "letters", stream: null, running: false, busy: false, recording: false, sid: null, timer: null,
  inflight: null, page: "overview", modes: [], metrics: [], hist: [], tr: [], votes: [], stable: null, logged: null, cur: null };
const store = { get(k, d) { try { return JSON.parse(sessionStorage.getItem(k)) ?? d; } catch { return d; } },
  set(k, v) { try { sessionStorage.setItem(k, JSON.stringify(v)); } catch { /* storage may be blocked */ } } };
S.hist = store.get("sb_hist", []); S.tr = store.get("sb_tr", []);
const mode = () => S.modes.find((m) => m.id === `${S.lang}_${S.kind}`);

/* ---------- API ---------- */
async function api(path, opts) {
  let r;
  try { r = await fetch(path, opts); } catch { setServer(false); throw Object.assign(new Error("Cannot reach the Flask server. Make sure `python app.py` is still running, then reload."), { code: "offline" }); }
  setServer(true);
  let j = null; try { j = await r.json(); } catch { /* non-JSON error */ }
  if (!r.ok) throw Object.assign(new Error(j?.error?.message || `Request failed (${r.status}).`), { code: j?.error?.code || "http", status: r.status });
  return j;
}
function setServer(ok) { const p = $("#srv"); p.className = "pill " + (ok ? "ok" : "bad"); p.lastElementChild.textContent = ok ? "Server online" : "Server unreachable"; }

/* ---------- navigation / theme ---------- */
function route() {
  const page = (location.hash || "#overview").slice(1); S.page = $("#p-" + page) ? page : "overview";
  $$(".page").forEach((p) => p.classList.toggle("on", p.id === "p-" + S.page));
  $$("#nav a").forEach((a) => a.classList.toggle("on", a.dataset.page === S.page));
  window.scrollTo(0, 0);
}
addEventListener("hashchange", route);
function setTheme(t) { document.documentElement.dataset.theme = t; try { localStorage.setItem("sb_theme", t); } catch { /* ignore */ } }
try { setTheme(localStorage.getItem("sb_theme") || "dark"); } catch { /* ignore */ }
$("#theme").onclick = () => setTheme(document.documentElement.dataset.theme === "dark" ? "light" : "dark");

/* ---------- data loading + overview / models / performance ---------- */
async function load() {
  try {
    const [m, mt] = await Promise.all([api("/api/models"), api("/api/metrics")]);
    S.modes = m.models; S.metrics = mt.metrics;
  } catch (e) { $("#ov-modes").innerHTML = `<div class="banner">${esc(e.message)}</div>`; return; }
  renderOverview(); renderModels(); renderPerf(); syncStudio();
}
const statusOf = (m) => m.loaded ? ["ok", "Loaded"] : m.labels.length ? ["meta", "Not loaded (metadata only)"] : ["", "Unavailable"];
function renderOverview() {
  $("#ov-modes").innerHTML = S.modes.map((m) => { const [c, t] = statusOf(m);
    return `<div class="card mode ${c}"><b>${m.lang.toUpperCase()} ${m.kind}</b><span class="st"><i></i>${t}</span>
      <span class="n">${m.n_labels || "-"}</span><span class="muted sm">${m.n_labels ? "labels" : esc(m.reason || "no labels")}</span></div>`; }).join("");
  const rows = S.metrics.filter((m) => m.saved?.test).map((m) => `<div class="rec-row"><span><b>${m.lang.toUpperCase()} words</b> <small>${m.n_labels} labels</small></span>
      <span>test top-1 ${pct(m.saved.test.top1)} &nbsp; top-3 ${pct(m.saved.test.top3)} <small>n=${m.saved.test.n}</small></span></div>`);
  $("#ov-metrics").innerHTML = rows.join("") + `<div class="empty">Letter models: no saved evaluation (unavailable).</div>`;
  renderRecent();
}
function renderRecent() {
  const h = S.hist.slice(0, 5);
  $("#ov-recent").innerHTML = h.length ? h.map(histRow).join("") : `<div class="empty">No predictions yet this session. Open the studio and sign something.</div>`;
}
function renderModels() {
  const q = ($("#vocab-q").value || "").trim().toLowerCase();
  $("#model-list").innerHTML = S.modes.map((m) => { const [c, t] = statusOf(m);
    const shown = m.labels.filter((l) => !q || l.toLowerCase().includes(q) || pretty(l).includes(q));
    const ev = m.metrics ? ["val", "test"].filter((k) => m.metrics[k]).map((k) => `${k === "val" ? "Validation" : "Test"}: top-1 ${pct(m.metrics[k].top1)}, top-3 ${pct(m.metrics[k].top3)} (n=${m.metrics[k].n})`).join("<br>") : `<span class="muted">${esc(m.metrics_note || "Not available")}</span>`;
    return `<div class="card mode ${c}"><div class="row between"><h2>${m.lang.toUpperCase()} ${m.kind}</h2><span class="st"><i></i>${t}</span></div>
      <dl><dt>Format</dt><dd>${esc(m.format)}</dd><dt>Dependencies</dt><dd>${m.deps.map(esc).join(", ")}</dd>
      ${m.n_hands ? `<dt>Hands used</dt><dd>${m.n_hands}</dd>` : ""}<dt>Labels</dt><dd>${m.n_labels}${m.labels_source ? ` <span class="muted">(${esc(m.labels_source)})</span>` : ""}</dd>
      <dt>Saved evaluation</dt><dd>${ev}</dd>${m.reason ? `<dt>Status</dt><dd>${esc(m.reason)}</dd>` : ""}</dl>
      ${m.labels.length ? `<div class="labels">${m.labels.map((l) => `<span class="${shown.includes(l) ? "" : "dis"}">${esc(pretty(l))}</span>`).join("")}</div>
      <div class="muted sm" style="margin-top:.5rem">${shown.length} of ${m.labels.length} shown</div>` : ""}</div>`; }).join("");
}
$("#vocab-q").oninput = renderModels;

function cmpBars(title, key, split) {
  const rows = S.metrics.filter((m) => m.saved?.[split]).map((m) => `<div class="cmp-row"><b>${m.lang.toUpperCase()}</b>
    <div class="bar ${m.lang}"><i style="width:${m.saved[split][key] * 100}%"></i></div><span>${pct(m.saved[split][key])}</span></div>`).join("");
  return `<div class="card"><h2>${title}</h2><div class="cmp">${rows}</div></div>`;
}
function renderPerf() {
  const w = S.metrics.filter((m) => m.kind === "words" && m.saved);
  if (!w.length) { $("#perf").innerHTML = `<div class="banner">No saved word-model metrics were found in models/.</div>`; return; }
  const cards = w.map((m) => `<div class="card"><h2>${m.lang.toUpperCase()} words</h2><div class="metric-grid">
    ${["test", "val"].filter((k) => m.saved[k]).map((k) => `<div class="metric"><small>${k === "test" ? "Test" : "Validation"} top-1</small><b>${pct(m.saved[k].top1)}</b></div><div class="metric"><small>${k === "test" ? "Test" : "Validation"} top-3</small><b>${pct(m.saved[k].top3)}</b></div>`).join("")}
    <div class="metric"><small>Vocabulary</small><b>${m.n_labels}</b></div></div></div>`).join("");
  const table = w.flatMap((m) => ["val", "test"].filter((k) => m.saved[k]).map((k) => `<tr><td>${m.lang.toUpperCase()}</td><td>${k === "val" ? "Validation" : "Test"}</td>
    <td class="num">${pct(m.saved[k].top1, 2)}</td><td class="num">${pct(m.saved[k].top3, 2)}</td><td class="num">${m.saved[k].n}</td></tr>`)).join("");
  const ev = S.metrics.filter((m) => m.eval_results).map((m) => { const r = m.eval_results; const pc = Object.entries(r.per_class).sort((a, b) => a[1] - b[1]);
    return `<div class="card"><h2>Your own evaluation: ${m.lang.toUpperCase()} ${m.kind} <span class="tag">results/${m.id}.json</span></h2>
      <p class="muted sm">${r.n} samples, top-1 ${pct(r.top1)}${r.top3 ? `, top-3 ${pct(r.top3)}` : ""}. ${r.confusion_csv ? `Confusion matrix saved at results/${m.id}_confusion.csv.` : ""}</p>
      <div class="cmp">${pc.map(([k, v]) => `<div class="cmp-row" style="grid-template-columns:7rem 1fr 3.6rem"><span>${esc(pretty(k))}</span><div class="bar"><i style="width:${v * 100}%"></i></div><span>${pct(v, 0)}</span></div>`).join("")}</div></div>`; }).join("");
  $("#perf").innerHTML = `<div class="cols" style="grid-template-columns:1fr 1fr">${cards}</div>
    <div class="cols" style="grid-template-columns:1fr 1fr">${cmpBars("Top-1 on test set", "top1", "test")}${cmpBars("Top-3 on test set", "top3", "test")}
    ${cmpBars("Top-1 on validation set", "top1", "val")}${cmpBars("Top-3 on validation set", "top3", "val")}</div>
    <div class="card"><h2>Results table</h2><table><thead><tr><th>Language</th><th>Split</th><th class="num">Top-1</th><th class="num">Top-3</th><th class="num">Samples</th></tr></thead><tbody>${table}</tbody></table>
    <p class="muted sm" style="margin-top:.8rem">The saved metadata has no per-class results. Letter models have no saved evaluation at all.</p></div>
    ${ev || `<div class="card"><h2>Per-class results and confusion matrices</h2><p class="muted">None found. Generate them from your own recordings with the existing tool, then reload:</p>
    <p><code>python tools/evaluate_clips.py words --lang isl --clips clips</code></p><p style="margin-top:.4rem"><code>python tools/evaluate_clips.py letters --lang asl --images images</code></p></div>`}`;
}

/* ---------- studio state ---------- */
function banner(msg, info) { const b = $("#banner"); b.hidden = !msg; b.className = "banner" + (info ? " info" : ""); b.textContent = msg || ""; }
function phase(t) { $("#phase").textContent = t; }
function syncStudio() {
  const m = mode(); $$("#seg-lang button").forEach((b) => b.classList.toggle("on", b.dataset.v === S.lang));
  $$("#seg-kind button").forEach((b) => b.classList.toggle("on", b.dataset.v === S.kind));
  $("#mode-line").textContent = `Selected: ${S.lang.toUpperCase()} ${S.kind}. ` + (S.kind === "letters" ? "Hold a letter steady; predictions update about 3 times a second." : "Record one sign at a time; the model reads the motion over the whole recording.");
  $("#res-mode").textContent = `${S.lang.toUpperCase()} ${S.kind}`;
  const ok = !!m?.available; banner(ok ? (S.err || "") : `${S.lang.toUpperCase()} ${S.kind} is unavailable: ${m?.reason || "model status unknown"} Other modes still work.`);
  $("#btn-run").disabled = !ok || !S.stream;
  $("#btn-run span").textContent = S.kind === "words" ? (S.recording ? "Stop & predict" : "Record sign") : (S.running ? "Stop recognition" : "Start recognition");
  $("#btn-run use").setAttribute("href", S.running || S.recording ? "#i-stop" : S.kind === "words" ? "#i-rec" : "#i-play");
  $("#tips").innerHTML = S.kind === "letters"
    ? `<b>How to sign a letter</b><ul><li>${S.lang === "asl" ? "Show one hand, palm to the camera, fingers fully visible." : "Show both hands in frame; ISL letters use two."}</li><li>Hold still until the letter stays stable, then press Add to transcript.</li><li>Good light and a plain background help.</li></ul>`
    : `<b>How to sign a word</b><ul><li>Show your upper body and hands. Press Record sign.</li><li>Perform the sign once (about 2 to 3 seconds), then press Stop &amp; predict.</li><li>It stops by itself after 5 seconds.</li></ul>`;
  $("#tr-peek").textContent = S.tr.length ? "Transcript: " + trText().slice(-40) : "";
  setAddState();
}
$$("#seg-lang button, #seg-kind button").forEach((b) => b.onclick = async () => {
  S.err = ""; await stopAll(); S[b.parentElement.id === "seg-lang" ? "lang" : "kind"] = b.dataset.v; resetResult(); syncStudio();
});

/* ---------- camera ---------- */
$("#btn-cam").onclick = async () => S.stream ? stopCamera() : startCamera();
async function startCamera() {
  if (!navigator.mediaDevices?.getUserMedia) return banner("This browser blocks camera access here. Open http://localhost:5000 (not a network address) in Chrome, Edge or Firefox.");
  try {
    S.stream = await navigator.mediaDevices.getUserMedia({ video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: "user" }, audio: false });
  } catch (e) {
    const msg = { NotAllowedError: "Camera permission was denied. Click the camera icon in the address bar, allow access, then press Start camera.",
      NotFoundError: "No camera was found. Connect a webcam and try again.", NotReadableError: "The camera is in use by another app. Close it (Zoom, Teams, another tab) and try again." }[e.name];
    return banner(S.err = msg || "The camera could not be started. Check browser permissions and try again.");
  }
  const v = $("#video"); v.srcObject = S.stream; await v.play().catch(() => {});
  S.stream.getVideoTracks()[0].onended = () => stopCamera("Camera was disconnected.");
  $("#stage").classList.add("on"); $("#btn-cam span").textContent = "Stop camera"; phase("Camera ready"); syncStudio();
}
async function stopCamera(msg) {
  await stopAll(); S.stream?.getTracks().forEach((t) => t.stop()); S.stream = null; $("#video").srcObject = null;
  $("#stage").classList.remove("on"); $("#btn-cam span").textContent = "Start camera"; phase("Camera off"); clearOverlay(); syncStudio(); if (msg) banner(S.err = msg);
}
const cv = $("#grab"), ctx = cv.getContext("2d");
function grab() {   // un-mirrored frame (the CSS mirror is display-only), 640 px wide JPEG
  const v = $("#video"); if (!v.videoWidth) return Promise.resolve(null);
  cv.width = 640; cv.height = Math.round((v.videoHeight * 640) / v.videoWidth); ctx.drawImage(v, 0, 0, cv.width, cv.height);
  return new Promise((r) => cv.toBlob(r, "image/jpeg", 0.7));
}
function draw(hands) {
  const o = $("#overlay"), v = $("#video"); o.width = v.clientWidth; o.height = v.clientHeight; const c = o.getContext("2d");
  c.clearRect(0, 0, o.width, o.height); c.fillStyle = "#3dd6f5";
  // video uses object-fit: cover, so map normalised coordinates through the same crop
  const sc = Math.max(o.width / v.videoWidth, o.height / v.videoHeight), dx = (v.videoWidth * sc - o.width) / 2, dy = (v.videoHeight * sc - o.height) / 2;
  hands.forEach((h) => h.forEach(([x, y]) => { c.beginPath(); c.arc(x * v.videoWidth * sc - dx, y * v.videoHeight * sc - dy, 3.5, 0, 7); c.fill(); }));
}
const clearOverlay = () => { const o = $("#overlay"); o.getContext("2d").clearRect(0, 0, o.width, o.height); };
function handChips(l, r) { $("#hl").classList.toggle("on", !!l); $("#hr").classList.toggle("on", !!r); }

/* ---------- run / stop ---------- */
$("#btn-run").onclick = () => (S.err = "",  S.kind === "words" ? (S.recording ? wordStop() : wordStart()) : (S.running ? stopAll() : (S.running = true, S.votes = [], phase("Waiting for sign"), syncStudio())));
async function stopAll() {
  if (S.recording) await wordCancel();
  S.running = false; if (S.stream) phase("Camera ready"); clearOverlay(); handChips(0, 0); syncStudio();
}
function fatal(e) {
  S.err = e.message; banner(S.err);
  if (["model_unavailable", "landmark_assets", "mediapipe_missing", "offline", "server_error"].includes(e.code)) { S.running = false; if (S.recording) wordCancel(); phase("Stopped"); syncStudio(); }
}

/* letters: one frame per request, never overlapping */
setInterval(async () => {
  if (!S.running || S.busy || S.kind !== "letters" || S.page !== "studio") return;
  S.busy = true;
  try {
    const b = await grab(); if (!b) return;
    const r = await api(`/api/predict/letter?lang=${S.lang}`, { method: "POST", headers: { "Content-Type": "image/jpeg" }, body: b });
    if (!S.running) return; S.err = ""; banner("");
    draw(r.landmarks); handChips(r.hands > 0, r.hands > 1);
    S.votes.push(r.prediction && r.prediction.confidence > 0.5 ? r.prediction : null); S.votes = S.votes.slice(-8);   // same smoothing as demo/app.py
    const counts = {}; S.votes.forEach((v) => v && (counts[v.label] = (counts[v.label] || 0) + 1));
    const top = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
    S.stable = top && top[1] >= 3 ? top[0] : null;
    if (!r.hands) phase("No hand detected");
    else if (S.kind === "letters" && r.hands < r.hands_required) phase(`Show ${r.hands_required} hands`);
    else phase(S.stable ? "Sign recognised" : "Waiting for sign");
    if (S.stable) { const cs = S.votes.filter((v) => v?.label === S.stable).map((v) => v.confidence); const c = cs.reduce((a, b) => a + b, 0) / cs.length;
      S.cur = { label: S.stable, kind: "letter" }; showResult(S.stable, c, null, r.hands ? "Stable over the last few frames" : "");
      if (S.logged !== S.stable) { logHist(S.stable, c); S.logged = S.stable; } }
    else { S.logged = null; S.cur = null; showResult(null, 0, null, r.hands ? "Hold the sign steady" : "Show your hand to the camera"); }
  } catch (e) { fatal(e); } finally { S.busy = false; }
}, 300);

/* words: start a server recording, stream throttled frames, then finish for the prediction */
async function wordStart() {
  try {
    const r = await api("/api/predict/word/start", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ lang: S.lang }) });
    S.sid = r.session; S.recording = true; S.err = ""; resetResult(); banner(""); phase("Recording"); $("#rec-chip").hidden = false; $("#rec-n").textContent = 0;
    S.timer = setInterval(sendFrame, 130); S.auto = setTimeout(wordStop, 5000); syncStudio();
  } catch (e) { fatal(e); }
}
function sendFrame() {
  if (S.busy || !S.recording) return; S.busy = true;
  S.inflight = (async () => { try {
    const b = await grab(); if (!b || !S.sid) return;
    const r = await api(`/api/predict/word/frame?session=${S.sid}`, { method: "POST", headers: { "Content-Type": "image/jpeg" }, body: b });
    $("#rec-n").textContent = r.frames; draw([r.landmarks.left, r.landmarks.right].filter((h) => h.length)); handChips(r.left, r.right);
  } catch (e) { if (S.recording) { fatal(e); wordCancel(); } } finally { S.busy = false; } })();
}
function endRecording() { clearInterval(S.timer); clearTimeout(S.auto); S.recording = false; $("#rec-chip").hidden = true; clearOverlay(); handChips(0, 0); }
async function wordStop() {
  if (!S.recording) return; const sid = S.sid; endRecording(); phase("Processing"); syncStudio(); await S.inflight;
  try {
    const r = await api("/api/predict/word/finish", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ session: sid }) });
    const p = r.predictions; S.cur = { label: p[0].label, kind: "word" };
    showResult(p[0].label, p[0].confidence, p, `${r.frames} frames recorded, hands visible in ${r.hand_frames}`); logHist(p[0].label, p[0].confidence); phase("Prediction ready");
  } catch (e) { showResult(null, 0, null, e.message); phase("Camera ready"); if (!["insufficient_frames", "no_hand", "no_session"].includes(e.code)) fatal(e); }
  syncStudio();
}
async function wordCancel() { const sid = S.sid; endRecording(); S.sid = null; if (sid) try { await api("/api/predict/word/cancel", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ session: sid }) }); } catch { /* server gone */ } syncStudio(); }

/* ---------- results, history ---------- */
function resetResult() { S.cur = null; S.stable = null; S.logged = null; S.votes = []; showResult(null, 0, null, "No prediction yet"); }
function showResult(label, conf, alts, sub) {
  const el = $("#pred"); el.textContent = label ? pretty(label) : "\u2014"; el.classList.toggle("dim", !label);
  $("#pred-sub").textContent = sub || ""; $("#conf-bar").style.width = label ? conf * 100 + "%" : "0"; $("#conf-txt").textContent = label ? pct(conf) : "-";
  $("#alts").innerHTML = alts ? `<div class="muted sm">Top 3</div>` + alts.map((a, i) => `<div class="alt"><span class="muted">${i + 1}</span><b>${esc(pretty(a.label))}</b><span>${pct(a.confidence)}</span><div class="bar"><i style="width:${a.confidence * 100}%"></i></div></div>`).join("") : "";
  setAddState();
}
function setAddState() { $("#btn-add").disabled = !S.cur; }
const histRow = (h) => `<div><span><b>${esc(pretty(h.label))}</b> <small>${esc(h.mode)}</small></span><span>${pct(h.conf, 0)} <small>${new Date(h.t).toLocaleTimeString()}</small></span></div>`;
function logHist(label, conf) {
  S.hist.unshift({ label, conf, mode: `${S.lang.toUpperCase()} ${S.kind}`, t: Date.now() }); S.hist = S.hist.slice(0, 50); store.set("sb_hist", S.hist); renderHist();
}
function renderHist() { $("#hist").innerHTML = S.hist.length ? S.hist.map(histRow).join("") : `<div class="empty">No predictions yet. Start recognition and sign something.</div>`; renderRecent(); }
$("#hist-clear").onclick = () => { S.hist = []; store.set("sb_hist", []); renderHist(); };

/* ---------- transcript (separate from history; only explicit actions add to it) ---------- */
function trText() {
  let out = "";
  for (const it of S.tr) { if (it.kind === "space") out += " "; else if (it.kind === "word") out += (out && !out.endsWith(" ") ? " " : "") + it.text + " "; else out += it.text; }
  return out;
}
function renderTr() {
  const t = trText(), el = $("#tr-text"); el.textContent = t.trimEnd() || "Nothing yet. Recognise a sign in the studio and press Add to transcript."; el.classList.toggle("empty", !t.trim());
  const words = t.trim() ? t.trim().split(/\s+/).length : 0; $("#tr-count").textContent = `${t.trimEnd().length} characters, ${words} word${words === 1 ? "" : "s"}, ${S.tr.length} item${S.tr.length === 1 ? "" : "s"}`;
  ["#tr-undo", "#tr-copy", "#tr-clear"].forEach((s) => $(s).disabled = !S.tr.length); store.set("sb_tr", S.tr); $("#tr-peek").textContent = S.tr.length ? "Transcript: " + t.slice(-40) : "";
}
$("#btn-add").onclick = () => {
  if (!S.cur) return;
  if (S.cur.kind === "letter" && S.cur.label === "del") S.tr.pop();            // the letter model has 'del' and 'space' classes
  else if (S.cur.kind === "letter" && S.cur.label === "space") S.tr.push({ kind: "space", text: " " });
  else S.tr.push({ kind: S.cur.kind, text: S.cur.kind === "word" ? pretty(S.cur.label) : S.cur.label });
  renderTr();
};
$("#tr-undo").onclick = () => { S.tr.pop(); renderTr(); $("#tr-msg").textContent = ""; };
$("#tr-clear").onclick = () => { S.tr = []; renderTr(); $("#tr-msg").textContent = "Transcript cleared."; };
$("#tr-copy").onclick = async () => {
  const t = trText().trimEnd(), msg = $("#tr-msg");
  try { await navigator.clipboard.writeText(t); msg.textContent = "Copied to clipboard."; }
  catch {
    try { const ta = Object.assign(document.createElement("textarea"), { value: t }); document.body.append(ta); ta.select(); const ok = document.execCommand("copy"); ta.remove(); msg.textContent = ok ? "Copied to clipboard." : "Copy failed. Select the text above and press Ctrl+C."; }
    catch { msg.textContent = "Copy failed. Select the text above and press Ctrl+C."; }
  }
};

/* ---------- boot ---------- */
async function boot() {
  route(); renderHist(); renderTr(); resetResult(); syncStudio();
  try { const st = await api("/api/status"); if (st.notes?.length) console.warn(st.notes); } catch { /* shown by api() */ }
  await load();
}
boot();
