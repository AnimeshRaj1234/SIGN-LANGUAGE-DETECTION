# SignBridge dashboard - setup guide

A browser dashboard around the **already-trained** ASL/ISL models. Nothing is retrained. Training stays in the Kaggle/Colab notebooks.

## What works with the files in this repository

| Mode | Status | Why |
|---|---|---|
| ASL letters | Ready | `models/asl_letters_np.zip` is a renamed `.npz`; the dashboard copies it to `models/_runtime/asl_letters_np.npz` once. |
| ASL words (23 labels) | Needs PyTorch | `models/asl_models.zip` -> `asl_words.pt` + `.json` |
| ISL words (51 labels) | Needs PyTorch | `models/isl_models.zip` -> `isl_words.pt` + `.json` |
| ISL letters | **Unavailable** | The repo contains no ISL letters model. The mode is disabled; it does not fake output. |

Saved metrics exist only for the two word models (validation/test top-1/top-3). Letter models have none.

## 1. Python
Python **3.10 - 3.12** (same as `requirements-local.txt`). Check with `python --version`.

## 2. Virtual environment and dependencies (Windows PowerShell)
Why: an isolated environment keeps MediaPipe/PyTorch versions from clashing with other projects.
```powershell
cd path\to\sign-language-main
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install torch --index-url https://download.pytorch.org/whl/cpu
pip install -r requirements-dashboard.txt
```
If activation is blocked: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`, then activate again.

## 3. Model files
Nothing to do by hand. On start-up the app extracts only whitelisted files from the zips in `models/` into `models/_runtime/` (skipped when already up to date). Your original zips are never modified.

MediaPipe also needs two small files (`hand_landmarker.task`, `pose_landmarker_lite.task`). The existing `slr/landmarks.py` downloads them to `~\.cache\slr` on first use (internet needed **once**). To go offline-first, download them into `models/`:
```powershell
Invoke-WebRequest https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task -OutFile models\hand_landmarker.task
Invoke-WebRequest https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/latest/pose_landmarker_lite.task -OutFile models\pose_landmarker_lite.task
```

## 4. Run
```powershell
python app.py
```
Open **http://localhost:5000**. Use `localhost` (or 127.0.0.1): browsers only allow camera access on secure origins. Set `$env:PORT=5050` first if 5000 is busy.
Check the **Models & vocabulary** page: ASL letters, ASL words and ISL words should read "Loaded".

## 5. Using the studio
1. **Start camera** and allow permission.
2. Choose **ASL / ISL** and **Letters / Words**.
3. *Letters*: **Start recognition**, hold a sign steady. The big letter appears once it is stable across recent frames (same smoothing as the desktop demo). Press **Add to transcript** to confirm it. ASL letters include `space` and `del` classes; adding them inserts a space or deletes the last item.
4. *Words*: press **Record sign**, perform the sign once, press **Stop & predict** (auto-stops at 5 s). The server feeds the frames through `FrameTracker`, then the existing trim -> 32-frame resample -> normalise -> Transformer path. You get the top 3.

Frames are held in memory only for the recording and are never written to disk.

## 6. Troubleshooting
| Message | Cause / fix |
|---|---|
| Camera permission denied | Click the camera icon in the address bar, allow, press Start camera. |
| Camera in use | Close Zoom/Teams/other tabs. |
| "MediaPipe model files ... could not be loaded" | First-run download failed. Run the `Invoke-WebRequest` lines above. |
| "PyTorch is not installed" | Run the `pip install torch ...` line. Word modes stay disabled until then; vocabulary and metrics still display from the JSON. |
| ISL letters unavailable | Expected: no ISL letters model exists yet. Train one with `scripts/letters.py` and place `isl_letters_np.npz` or `isl_letters.joblib` in `models/`. |
| Server unreachable | `python app.py` stopped. Restart it and reload. |
| Words predicted poorly | Keep upper body and both hands in view, good light, one sign per recording. Saved metrics are held-out dataset results, not webcam accuracy. |

## 7. Existing evaluation tools (unchanged)
```powershell
python tools\record_clips.py --lang isl --words hello water --per-word 5
python tools\evaluate_clips.py words --lang isl --clips clips
python tools\evaluate_clips.py letters --lang asl --images images
```
They write `results\<lang>_words.json` / `<lang>_letters.json` and a confusion CSV. If `results/` exists, the Performance page shows the per-class bars automatically.

## 8. Dashboard vs desktop demo
| | `demo/app.py` | Dashboard |
|---|---|---|
| Camera | OpenCV window | Browser `getUserMedia` |
| Landmarks | In-process | Server, from JPEG frames (about 3 fps letters, about 8 fps words) |
| Words | SPACE to record/stop | Record sign / Stop & predict |
| Models | same `slr` code and trained files | same |

## 9. Layout
`app.py` routes | `services/models.py` model prep, loading, metadata | `services/vision.py` frame inference and word sessions | `templates/`, `static/` UI | `slr/`, `models/`, `tools/`, `notebooks/`, `demo/` untouched.
