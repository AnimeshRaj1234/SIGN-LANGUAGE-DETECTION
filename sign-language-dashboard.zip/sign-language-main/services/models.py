"""Model discovery, one-time safe archive extraction, metadata validation.

Why this exists: the repo ships models as nested zips, but slr.inference.Models wants plain files in one
folder. We prepare that folder once (models/_runtime/) and then reuse the *existing* loaders unchanged.
"""
import importlib.util
import json
import logging
import shutil
import sys
import zipfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from slr.inference import Models, NumpyMLP  # noqa: E402

log = logging.getLogger("signbridge")
MODELS_DIR, RUNTIME, RESULTS = ROOT / "models", ROOT / "models" / "_runtime", ROOT / "results"
LANGS = ("asl", "isl")
MODES = [f"{l}_{k}" for l in LANGS for k in ("letters", "words")]
NPZ_KEYS = {"mean.npy", "scale.npy", "classes.npy", "n_hands.npy", "n_layers.npy"}
MAX_MEMBER = 200 * 1024 * 1024        # refuse suspiciously large archive members (zip bombs)


class ModeUnavailable(Exception):
    pass


def _stale(src, dst):
    return not dst.exists() or dst.stat().st_mtime < src.stat().st_mtime


def prepare_runtime():
    """Copy/extract model files into models/_runtime/. Idempotent: nothing is redone when files are fresh.
    Only whitelisted file names are written, and only into RUNTIME (archive paths are never trusted)."""
    RUNTIME.mkdir(parents=True, exist_ok=True)
    notes = []
    wanted = set()
    for l in LANGS:
        wanted |= {f"{l}_words.pt", f"{l}_words.json", f"{l}_letters_np.npz"}
    for name in wanted | {f"{l}_letters.joblib" for l in LANGS}:     # loose files placed directly in models/
        src = MODELS_DIR / name
        if src.is_file() and _stale(src, RUNTIME / name):
            shutil.copyfile(src, RUNTIME / name)
    for z in sorted(MODELS_DIR.glob("*.zip")):
        try:
            with zipfile.ZipFile(z) as zf:
                names = {PurePosixPath(i.filename).name: i for i in zf.infolist() if not i.is_dir()}
                lang = z.name.split("_")[0]
                if z.name == f"{lang}_letters_np.zip" and lang in LANGS:
                    # a renamed .npz: an .npz *is* a zip of .npy files, so validate and copy it under the right name
                    if NPZ_KEYS <= set(names) and _stale(z, RUNTIME / f"{lang}_letters_np.npz"):
                        shutil.copyfile(z, RUNTIME / f"{lang}_letters_np.npz")
                    continue
                for n in wanted & set(names):
                    if names[n].file_size > MAX_MEMBER:
                        notes.append(f"{z.name}: {n} skipped (too large)")
                    elif _stale(z, RUNTIME / n):
                        with zf.open(names[n]) as s, open(RUNTIME / n, "wb") as d:
                            shutil.copyfileobj(s, d)
        except (zipfile.BadZipFile, OSError):
            notes.append(f"{z.name}: could not be read")
    return notes


def read_word_meta(lang):
    """Validate models/_runtime/<lang>_words.json -> {labels, val, test} or None."""
    p = RUNTIME / f"{lang}_words.json"
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        labels = d["labels"]
        assert isinstance(labels, list) and labels and all(isinstance(x, str) for x in labels)
        out = {"labels": labels}
        for split in ("val", "test"):
            m = (d.get("metrics") or {}).get(split)
            if m and 0 <= float(m["top1"]) <= 1 and 0 <= float(m["top3"]) <= 1 and int(m["n"]) > 0:
                out[split] = {"top1": float(m["top1"]), "top3": float(m["top3"]), "n": int(m["n"])}
        return out
    except (OSError, ValueError, KeyError, TypeError, AssertionError):
        return None


def read_results(mode):
    """Optional output of tools/evaluate_clips.py: results/<mode>.json (+ <mode>_confusion.csv)."""
    try:
        d = json.loads((RESULTS / f"{mode}.json").read_text(encoding="utf-8"))
        per = {str(k): float(v) for k, v in (d.get("per_class") or {}).items()}
        return {"n": int(d["n"]), "top1": float(d["top1"]), "top3": float(d.get("top3", 0)), "per_class": per,
                "confusion_csv": (RESULTS / f"{mode}_confusion.csv").exists()}
    except (OSError, ValueError, KeyError, TypeError):
        return None


class ModelStore:
    def __init__(self):
        self.notes, self.errors = prepare_runtime(), {}
        self.torch_ok = importlib.util.find_spec("torch") is not None
        # Models() on a folder with no files gives empty dicts; we fill them one artifact at a time so a single
        # bad file disables only its own mode instead of crashing everything.
        self.M = Models(RUNTIME / "_none")
        for lang in LANGS:
            npz, jl = RUNTIME / f"{lang}_letters_np.npz", RUNTIME / f"{lang}_letters.joblib"
            try:
                if npz.exists():
                    self.M.letters[lang] = NumpyMLP(npz)
                elif jl.exists():
                    import joblib
                    self.M.letters[lang] = joblib.load(jl)
            except Exception:
                log.exception("letters %s failed to load", lang)
                self.errors[f"{lang}_letters"] = "The model file exists but could not be loaded."
            pt = RUNTIME / f"{lang}_words.pt"
            if pt.exists():
                if not self.torch_ok:
                    self.errors[f"{lang}_words"] = "PyTorch is not installed (pip install torch)."
                else:
                    try:
                        from slr.word_model import load_model
                        self.M.words[lang] = load_model(pt)
                    except Exception:
                        log.exception("words %s failed to load", lang)
                        self.errors[f"{lang}_words"] = "The model file exists but could not be loaded."

    def require(self, mode):
        if not self.M.available(mode):
            raise ModeUnavailable(self.describe(mode)["reason"] or "This mode is unavailable.")

    def assets(self):
        dirs = [RUNTIME.parent, RUNTIME.parent / "mp", Path.home() / ".cache" / "slr"]
        return {n: any((d / n).exists() for d in dirs) for n in ("hand_landmarker.task", "pose_landmarker_lite.task")}

    def describe(self, mode):
        lang, kind = mode.split("_")
        loaded = self.M.available(mode)
        d = {"id": mode, "lang": lang, "kind": kind, "loaded": loaded, "available": loaded, "reason": None,
             "labels": [], "labels_source": None, "metrics": None, "eval_results": read_results(mode)}
        if kind == "letters":
            d["format"] = "NumPy MLP (.npz), or scikit-learn (.joblib)"
            d["deps"] = ["mediapipe", "numpy"]
            if loaded:
                m = self.M.letters[lang]
                d["labels"] = list(m["classes"] if isinstance(m, dict) else m.classes)
                d["n_hands"] = int(m["n_hands"] if isinstance(m, dict) else m.n_hands)
                d["labels_source"] = "model file"
            d["metrics_note"] = "No letter-model evaluation is saved in the repository."
        else:
            d["format"] = "PyTorch Transformer (.pt) on 32 x 67-point keypoint sequences"
            d["deps"] = ["mediapipe", "torch", "numpy", "opencv-python"]
            meta = read_word_meta(lang)
            if loaded:
                d["labels"], d["labels_source"] = list(self.M.words[lang][1]), "model file"
            elif meta:
                d["labels"], d["labels_source"] = meta["labels"], "metadata JSON only (model not loaded)"
            if meta:
                d["metrics"] = {k: meta[k] for k in ("val", "test") if k in meta}
        if not loaded:
            d["reason"] = self.errors.get(mode) or (
                f"No {lang.upper()} {kind} model file found in models/." if not (RUNTIME / (
                    f"{lang}_words.pt" if kind == "words" else f"{lang}_letters_np.npz")).exists()
                else "Model could not be loaded.")
        d["n_labels"] = len(d["labels"])
        return d
