"""Camera-frame inference built on the existing slr pipeline (HandDetector, FrameTracker, Models).

Letters: one JPEG frame -> hand landmarks -> Models.letter()  (stateless, one request = one answer).
Words:   a *recording session*: many frames -> FrameTracker -> (T, 67, 2) sequence -> Models.word().
         A single frame can never be a word, because the model reads motion over time.
"""
import logging
import threading
import time
import uuid

import cv2
import numpy as np

log = logging.getLogger("signbridge")
MAX_BYTES, MAX_SIDE = 2 * 1024 * 1024, 960
MAX_WORD_FRAMES, MIN_WORD_FRAMES, SESSION_TTL, MAX_SESSIONS = 200, 8, 30, 3   # MIN matches demo/app.py


class VisionError(Exception):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code, self.message, self.status = code, message, status


def decode_frame(data):
    """Validate + decode a JPEG into an RGB array (never written to disk)."""
    if not data:
        raise VisionError("invalid_frame", "No image received. Send one JPEG frame in the request body.")
    if len(data) > MAX_BYTES:
        raise VisionError("frame_too_large", "Frame is larger than 2 MB. Lower the capture size.", 413)
    if data[:2] != b"\xff\xd8":
        raise VisionError("invalid_frame", "Frame must be a JPEG image.")
    img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise VisionError("invalid_frame", "The image could not be decoded.")
    if max(img.shape[:2]) > MAX_SIDE:
        s = MAX_SIDE / max(img.shape[:2])
        img = cv2.resize(img, None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
    return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)     # NOT mirrored: the models were trained on un-mirrored frames


def _pts(a):
    return [[round(float(x), 4), round(float(y), 4)] for x, y in a[:, :2]]


def _landmark_error(e):
    if isinstance(e, ImportError):
        return VisionError("mediapipe_missing", "MediaPipe is not installed. Run: pip install -r requirements-dashboard.txt", 503)
    log.exception("landmark model failed")
    return VisionError("landmark_assets", "MediaPipe model files (hand_landmarker.task / pose_landmarker_lite.task) "
                       "could not be loaded. They download once on first use; connect to the internet once or copy "
                       "them into models/. See DASHBOARD_SETUP.md.", 503)


class Vision:
    def __init__(self, store):
        self.store, self._lock = store, threading.Lock()   # MediaPipe objects are not thread-safe: serialize them
        self._hands, self._sessions = {}, {}

    def _require(self, mode):
        from .models import ModeUnavailable
        try:
            self.store.require(mode)
        except ModeUnavailable as e:
            raise VisionError("model_unavailable", str(e), 503)

    # ---------------- letters ----------------
    def letter(self, lang, data):
        self._require(f"{lang}_letters")
        rgb = decode_frame(data)
        with self._lock:
            try:
                if lang not in self._hands:         # created once, reused for every request
                    from slr.landmarks import HandDetector
                    self._hands[lang] = HandDetector(1 if lang == "asl" else 2, video=False)
            except Exception as e:
                raise _landmark_error(e)
            hands = self._hands[lang](rgb)
            res = self.store.M.letter(lang, hands) if hands else None
        m = self.store.M.letters[lang]
        need = int(m["n_hands"] if isinstance(m, dict) else m.n_hands)
        return {"hands": len(hands), "hands_required": need, "landmarks": [_pts(h) for h in hands],
                "prediction": {"label": res[0], "confidence": res[1]} if res else None}

    # ---------------- words ----------------
    def _purge(self):
        now = time.time()
        for sid in [k for k, s in self._sessions.items() if now - s["t"] > SESSION_TTL]:
            self._close(self._sessions.pop(sid))

    def _close(self, s):
        with self._lock:
            try:
                s["tracker"].close()
            except Exception:
                pass

    def word_start(self, lang):
        self._require(f"{lang}_words")
        self._purge()
        if len(self._sessions) >= MAX_SESSIONS:
            raise VisionError("busy", "Too many recordings are in progress. Wait a moment and try again.", 429)
        with self._lock:
            try:
                from slr.landmarks import FrameTracker
                tracker = FrameTracker()            # fresh tracker per sign, like tools/evaluate_clips.py
            except Exception as e:
                raise _landmark_error(e)
        sid = uuid.uuid4().hex
        self._sessions[sid] = {"tracker": tracker, "frames": [], "lang": lang, "t": time.time()}
        return {"session": sid, "max_frames": MAX_WORD_FRAMES, "min_frames": MIN_WORD_FRAMES}

    def _get(self, sid):
        s = self._sessions.get(sid)
        if not s:
            raise VisionError("no_session", "Recording not found or expired. Press Record sign to start again.", 404)
        return s

    def word_frame(self, sid, data):
        s = self._get(sid)
        if len(s["frames"]) >= MAX_WORD_FRAMES:
            raise VisionError("too_many_frames", "Recording limit reached. Stop and predict.", 409)
        rgb = decode_frame(data)
        with self._lock:
            fr = s["tracker"](rgb)                  # (67, 2), NaN where not detected
        s["frames"].append(fr)
        s["t"] = time.time()
        left, right = [not np.isnan(fr[a:b]).any() for a, b in ((25, 46), (46, 67))]
        return {"frames": len(s["frames"]), "left": left, "right": right, "pose": not bool(np.isnan(fr[:25]).all()),
                "landmarks": {"left": _pts(fr[25:46]) if left else [], "right": _pts(fr[46:67]) if right else []}}

    def word_cancel(self, sid):
        s = self._sessions.pop(sid, None)
        if s:
            self._close(s)

    def word_finish(self, sid):
        s = self._get(sid)
        self._sessions.pop(sid, None)
        self._close(s)
        n = len(s["frames"])
        if n < MIN_WORD_FRAMES:
            raise VisionError("insufficient_frames", f"Only {n} frames were captured; at least {MIN_WORD_FRAMES} are "
                              "needed. Record for 2 to 3 seconds while performing the sign.", 422)
        seq = np.stack(s["frames"])
        hand_frames = int((~np.isnan(seq[:, 25:67, 0]).all(1)).sum())    # same visibility test as trim_and_resample
        if hand_frames < 4:
            raise VisionError("no_hand", "No hands were detected during the recording. Keep your hands in view, "
                              "well lit, and try again.", 422)
        try:
            preds = self.store.M.word(s["lang"], seq)      # trim -> resample to 32 -> normalise -> transformer
        except Exception:
            log.exception("word inference failed")
            raise VisionError("inference_failed", "Prediction failed on the server. Check the server console.", 500)
        return {"frames": n, "hand_frames": hand_frames,
                "predictions": [{"label": l, "confidence": float(p)} for l, p in preds]}
