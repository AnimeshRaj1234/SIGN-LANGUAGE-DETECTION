"""Dashboard services: model discovery/loading and camera-frame inference."""
